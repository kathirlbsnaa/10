import Form from './Form';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>PERSONAL INFORMATION</h1>
      <Form/>
    </div>
  );
}

export default App;
